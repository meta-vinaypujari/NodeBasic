var calc = require('./calc.js')

var res = calc.add(4,5);
console.log(res);




